# CS325-400-Project-1
Project Group # 6; Members: Kelsey Helms, Jay Steingold, Johannes Pikel

In order to run the file on the Flip server please have MSS_Problems.txt in the same directory as maxSubArray.py.  From that directory please run the file with "python maxSubArray.py" When asked to enter a file name leave the line blank and hit [enter] it will default to MSS_Problems.txt

The output file MSS_results.txt will be created in the same directory as the maxsubarray.py

The output will include a heading in the text for the type of algorithm, such as:

Mss_Results.txt will look like the below assuming there were three arrays read in and Enumeration ran first and then iteration.

Enumeration
[Original array in format: 1, 2, ..., n]
[Max sub array: 1, 2, ..., n]
Max sum

[Original array in format: 1, 2, ..., n]
[Max sub array: 1, 2, ..., n]
Max sum

[Original array in format: 1, 2, ..., n]
[Max sub array: 1, 2, ..., n]
Max sum

Iteration
[Original array in format: 1, 2, ..., n]
[Max sub array: 1, 2, ..., n]
Max sum

[Original array in format: 1, 2, ..., n]
[Max sub array: 1, 2, ..., n]
Max sum

[Original array in format: 1, 2, ..., n]
[Max sub array: 1, 2, ..., n]
Max sum
